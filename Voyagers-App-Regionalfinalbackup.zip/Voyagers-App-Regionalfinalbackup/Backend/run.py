from workflow import app
import utils.security as security
import json

def remove_none(d):
    if isinstance(d, dict):
        return {k: remove_none(v) for k, v in d.items() if v is not None}
    elif isinstance(d, list):
        return [remove_none(v) for v in d if v is not None]
    else:
        return d
    
def calling_langgarph(user_id: int,user_input: str):
    
    result = app.invoke({
        "id" : user_id,
        "query": user_input
    })

    if(result['intent'] == "chat"):
        raw_output = result['output']
        cleaned = raw_output.strip("`").replace("json", "", 1).strip()
        data = json.loads(cleaned)
        output_json = json.dumps(data, indent=4)
        return output_json
    else:
        cleaned_output = remove_none(result)
        output_json = json.dumps(cleaned_output, indent=4)
        return output_json