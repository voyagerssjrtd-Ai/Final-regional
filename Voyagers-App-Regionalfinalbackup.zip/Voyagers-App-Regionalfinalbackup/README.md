# Portable-UX
This is a Frontend Portable UI UX where planned to Integrate with any backend easily 


Run this before running any scripts in the powershell terminal

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

npm config set strict-ssl false

npm config set registry http://registry.npmjs.org/

npm install

npm run dev

cd Backend
python -m venv venv
venv\Scripts\activate      # on powershell

pip install -r requirements.txt

uvicorn app.main:app --reload

-------------------
Run this before running any scripts in the powershell terminal

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

npm config set strict-ssl false

npm config set registry http://registry.npmjs.org/

npm install

npm run dev

pip install -r requirements.txt

python uvicorn app.main:app --reload --host 0.0.0.0 --port 8000