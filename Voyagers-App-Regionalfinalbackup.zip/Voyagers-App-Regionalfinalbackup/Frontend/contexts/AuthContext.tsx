// src/contexts/AuthContext.tsx
import React, { createContext, useContext, useState } from "react";

// shape of the user object coming from backend
interface User {
  id: string;
  email: string;
  full_name: string;
}

// what the context will expose
interface AuthContextType {
  user: User | null;
  login: (data: User) => void;
}

// create typed context (can be undefined before provider mounts)
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = (data: User) => {
    setUser(data);

    // store to localStorage for ChatUI / other pages
    localStorage.setItem("user_id", data.id);
    localStorage.setItem("user_name", data.full_name);
    localStorage.setItem("user_email", data.email);
  };

  return (
    <AuthContext.Provider value={{ user, login }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
};
