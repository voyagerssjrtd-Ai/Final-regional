import React from "react";
import { Message } from "../../types/chat";

export function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-xl px-4 py-2 rounded-2xl whitespace-pre-wrap shadow 
          ${isUser ? "bg-blue-600 text-white" : "bg-white text-gray-900"}`}
      >
        {message.content}
      </div>
    </div>
  );
}
