import React from "react";

interface SidebarProps {
  chats: { id: string; title: string }[];
  currentChat: string | null;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
}

export default function Sidebar({
  chats,
  currentChat,
  onNewChat,
  onSelectChat,
  onDeleteChat,
}) {
  const userName = localStorage.getItem("user_name") || "User";

  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <button
          onClick={onNewChat}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold"
        >
          + New Chat
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {chats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => onSelectChat(chat.id)}
            className={`flex justify-between items-center px-3 py-2 rounded-md cursor-pointer ${
              chat.id === currentChat
                ? "bg-gray-700 text-white"
                : "hover:bg-gray-800 text-gray-300"
            }`}
          >
            <span className="truncate">{chat.title}</span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteChat(chat.id);
              }}
              className="text-red-400 hover:text-red-200 text-sm px-1"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-gray-700 flex items-center gap-3">
        <div className="w-9 h-9 bg-blue-500 rounded-full flex items-center justify-center font-bold">
          {userName.charAt(0)}
        </div>
        <div className="text-sm">
          <div className="font-semibold">{userName}</div>
          <div className="text-gray-400 text-xs">Logged in</div>
        </div>
      </div>
    </div>
  );
}
