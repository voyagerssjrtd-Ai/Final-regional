import React, { useState, useEffect, useRef } from "react";
import { ArrowUpCircle, Mic } from "lucide-react";
import Sidebar from "./Sidebar";
import { MessageBubble } from "./MessageBubble";
import { Message, ChatBackend } from "../../types/chat";

// fallback title generator
function generateTitleFallback(text: string): string {
  if (!text) return "New Chat";
  let cleaned = text.replace(/[^a-zA-Z0-9 ]/g, "").split(" ");
  const sliced = cleaned.filter((w) => w.length > 2).slice(0, 6).join(" ");
  const titled = sliced.charAt(0).toUpperCase() + sliced.slice(1);
  return titled + "…";
}

export default function ChatUI({ backend }: { backend: ChatBackend }) {
  const userName = localStorage.getItem("user_name") || "User";

  // Chats: { id, title, messages[] }
  const [chats, setChats] = useState<
    { id: string; title: string; messages: Message[] }[]
  >([]);

  // Current chat ID + messages
  const [currentChat, setCurrentChat] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  // UI / Input states
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Streaming partial text per chat
  const [streamingByChat, setStreamingByChat] = useState<Record<string, string>>(
    {}
  );

  // Suggestions (3 follow-ups)
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // Attachments
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [showAttachMenu, setShowAttachMenu] = useState(false);

  // Voice recognition
  const [recognition, setRecognition] = useState<any>(null);
  const [recording, setRecording] = useState(false);
  const [speechLang, setSpeechLang] = useState("en-US");

  // Refs
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const controllerRef = useRef<AbortController | null>(null);
  const currentChatRef = useRef<string | null>(currentChat);

  // keep currentChat in a ref for callback closures
  useEffect(() => {
    currentChatRef.current = currentChat;
  }, [currentChat]);

  // Load chats from storage on mount
  useEffect(() => {
    const saved = localStorage.getItem("chats_full");
    if (saved) setChats(JSON.parse(saved));
  }, []);

  // Persist chats to localStorage
  useEffect(() => {
    localStorage.setItem("chats_full", JSON.stringify(chats));
  }, [chats]);

  // Auto-scroll to bottom
  const scrollToBottom = () =>
    messagesEndRef.current?.scrollIntoView({ behavior: "auto" });

  useEffect(scrollToBottom, [messages, streamingByChat]);

  // Initialize speech recognition
  useEffect(() => {
    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      const rec = new SpeechRec();
      rec.continuous = true;
      rec.interimResults = false;
      rec.lang = speechLang;

      rec.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((r: any) => r[0].transcript)
          .join("");
        setInput((prev) => prev + transcript + " ");
      };
      rec.onerror = () => setRecording(false);
      rec.onend = () => setRecording(false);

      setRecognition(rec);
    }
  }, [speechLang]);

  const toggleRecording = () => {
    if (!recognition) {
      alert("Speech recognition not supported");
      return;
    }
    if (recording) {
      recognition.stop();
      setRecording(false);
    } else {
      recognition.start();
      setRecording(true);
    }
  };

  // Request title from AI
  const requestTitle = async (reply: string, chatId: string) => {
    try {
      const prompt = `Generate a short 3–6 word title that summarizes the conversation based on this assistant message:\n"${reply}"`;
      const resMsg = await backend.sendMessage(prompt, { history: [] });
      const title = (resMsg?.content || "").trim().split("\n")[0] || generateTitleFallback(reply);

      setChats((prev) =>
        prev.map((c) => (c.id === chatId ? { ...c, title } : c))
      );
    } catch {
      const made = generateTitleFallback(reply);
      setChats((prev) =>
        prev.map((c) => (c.id === chatId ? { ...c, title: made } : c))
      );
    }
  };

  // Stop streaming
  const stopStreaming = () => {
    if (controllerRef.current) controllerRef.current.abort();
    setSending(false);
    setIsStreaming(false);
  };

  // Send message
  const sendMessage = async () => {
    if (!input.trim() && attachedFiles.length === 0) return;
    if (sending) return;

    if (recognition && recording) {
      recognition.stop();
      setRecording(false);
    }

    // create chat if needed
    let chatId = currentChat;
    if (!chatId) {
      chatId = Date.now().toString();
      setChats((prev) => [
        ...prev,
        { id: chatId!, title: "New chat", messages: [] },
      ]);
      setCurrentChat(chatId);
      setMessages([]);
    }

    // build user message
    let userText = input.trim();
    if (attachedFiles.length > 0) {
      userText +=
        "\n[Attached: " + attachedFiles.map((f) => f.name).join(", ") + "]";
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: userText,
      createdAt: new Date().toISOString(),
    };

    // update UI state
    setMessages((prev) => [...prev, userMsg]);
    setChats((prev) =>
      prev.map((c) =>
        c.id === chatId ? { ...c, messages: [...c.messages, userMsg] } : c
      )
    );

    setInput("");
    setAttachedFiles([]);
    setSending(true);
    setSuggestions([]);

    // prepare streaming
    controllerRef.current = new AbortController();
    const abortSignal = controllerRef.current.signal;
    setStreamingByChat((prev) => ({ ...prev, [chatId!]: "" }));
    setIsStreaming(true);

    // combine context
    const chatObj = chats.find((c) => c.id === chatId);
    const convo = (chatObj?.messages || []).concat(userMsg);
    const payload = convo
      .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
      .join("\n");

    try {
      if (typeof backend.streamMessage === "function") {
        let streamedText = "";

        await backend.streamMessage(
          payload,
          (chunk) => {
            streamedText += chunk;
            setStreamingByChat((prev) => ({
              ...prev,
              [chatId!]: streamedText,
            }));
          },
          async (finalMsg) => {
            if (!abortSignal.aborted && finalMsg?.content) {
              const botMsg: Message = {
                id: Date.now().toString(),
                role: "assistant",
                content: finalMsg.content,
                createdAt: new Date().toISOString(),
              };

              // update chat + UI
              setMessages((prev) => [...prev, botMsg]);
              setChats((prev) =>
                prev.map((c) =>
                  c.id === chatId
                    ? { ...c, messages: [...c.messages, botMsg] }
                    : c
                )
              );

              // clear streaming display
              setStreamingByChat((prev) => ({ ...prev, [chatId!]: "" }));

              // title + suggestions
              await requestTitle(finalMsg.content, chatId!);
              // await requestSuggestions(finalMsg.content);
            }
            setIsStreaming(false);
            setSending(false);
          },
          abortSignal
        );
      } else {
        // Non-streaming: call adapter.sendMessage which returns a normalized ChatMessage
        // Build a structured history (optional) to send to backend
        const history = convo
          .filter(m => m.role === "user" || m.role === "assistant")
          .map(m => ({ role: m.role as "user" | "assistant", content: m.content }))
          .slice(-12);

        // Only send the latest user message to backend, not the whole payload
        const botMsg = await backend.sendMessage(userMsg.content, { history });

        const finalMsg: Message = {
          id: botMsg.id || Date.now().toString(),
          role: botMsg.role as "assistant",
          content: botMsg.content,
          createdAt: botMsg.createdAt || new Date().toISOString(),
        };

        // update UI + chats
        setMessages((prev) => [...prev, finalMsg]);
        setChats((prev) =>
          prev.map((c) =>
            c.id === chatId
              ? { ...c, messages: [...c.messages, finalMsg] }
              : c
          )
        );

        // request title + suggestions from assistant reply
        await requestTitle(finalMsg.content, chatId!);
        // await requestSuggestions(finalMsg.content);
      }

    } catch (err: any) {
      if (err?.name !== "AbortError") {
        setError("Error sending message.");
      }
    } finally {
      setSending(false);
      setIsStreaming(false);
    }
  };

  // Select a chat
  const handleSelectChat = (id: string) => {
    setCurrentChat(id);
    const chat = chats.find((c) => c.id === id);
    setMessages(chat ? chat.messages : []);
    setSuggestions([]);
  };

  // Create new chat
  const handleNewChat = () => {
    const id = Date.now().toString();
    setChats((prev) => [...prev, { id, title: "New chat", messages: [] }]);
    setCurrentChat(id);
    setMessages([]);
    setSuggestions([]);
    setStreamingByChat((prev) => ({ ...prev, [id]: "" }));
  };

  // Delete chat
  const handleDeleteChat = (id: string) => {
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (currentChat === id) {
      setCurrentChat(null);
      setMessages([]);
      setSuggestions([]);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar
        chats={chats.map((c) => ({ id: c.id, title: c.title }))}
        currentChat={currentChat}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
      />

      <div className="flex flex-col flex-1 relative">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 pb-40">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}

          {/* Streaming bubble */}
          {currentChat && streamingByChat[currentChat] && (
            <div className="bg-gray-200 text-gray-800 p-3 rounded-xl w-max whitespace-pre-wrap">
              {streamingByChat[currentChat]}
              <span className="animate-pulse">|</span>
            </div>
          )}

          {/* Loading bubble */}
          {sending && !isStreaming && (
            <div className="bg-gray-300 text-gray-800 p-3 rounded-xl w-max animate-pulse">
              Thinking…
            </div>
          )}

          {error && (
            <div className="bg-red-200 text-red-800 p-3 rounded-xl">
              {error}
            </div>
          )}

          {/* Suggestions */}
          {suggestions.length > 0 && (
            <div className="flex gap-2 flex-wrap mt-3">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setInput(s)}
                  className="px-3 py-2 bg-white border rounded-full text-sm hover:bg-gray-50 shadow-sm"
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="absolute bottom-6 left-0 right-0 px-6">
          <div className="max-w-3xl mx-auto bg-white border shadow-lg rounded-xl p-3 flex flex-col gap-2">
            {/* File attachments */}
            {attachedFiles.length > 0 && (
              <div className="flex flex-wrap gap-2 px-2">
                {attachedFiles.map((file, idx) => (
                  <div
                    key={idx}
                    className="bg-gray-200 px-3 py-1 rounded flex items-center gap-2"
                  >
                    {file.name}
                    <button
                      onClick={() =>
                        setAttachedFiles((prev) =>
                          prev.filter((_, i) => i !== idx)
                        )
                      }
                      className="text-red-500"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-end gap-3">
              {/* Attach menu */}
              <div className="relative">
                <button
                  onClick={() => setShowAttachMenu((p) => !p)}
                  className="w-10 h-10 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-200 text-xl"
                >
                  +
                </button>

                {showAttachMenu && (
                  <div className="absolute bottom-12 left-0 bg-white border rounded-lg shadow p-2 space-y-1 w-40">
                    <button
                      className="w-full text-left px-2 py-1 hover:bg-gray-100"
                      onClick={() => {
                        document.getElementById("fileInput")?.click();
                        setShowAttachMenu(false);
                      }}
                    >
                      📄 Upload File
                    </button>
                    <button
                      className="w-full text-left px-2 py-1 hover:bg-gray-100"
                      onClick={() => {
                        document.getElementById("imageInput")?.click();
                        setShowAttachMenu(false);
                      }}
                    >
                      🖼️ Upload Image
                    </button>
                  </div>
                )}
              </div>

              {/* Input */}
              <textarea
                ref={inputRef}
                rows={1}
                className="flex-1 px-3 py-2 border-none outline-none resize-none"
                placeholder="Ask anything..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) =>
                  e.key === "Enter" &&
                  !e.shiftKey &&
                  (e.preventDefault(), sendMessage())
                }
                disabled={sending || isStreaming}
              />

              {/* Voice */}
              <button
                onClick={toggleRecording}
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  recording
                    ? "text-red-500 animate-pulse"
                    : "text-gray-500 hover:bg-gray-200"
                }`}
              >
                <Mic className="w-6 h-6" />
              </button>

              {/* Stop or Send */}
              {isStreaming || sending ? (
                <button
                  onClick={stopStreaming}
                  className="w-10 h-10 flex items-center justify-center text-red-500 hover:bg-red-100 rounded-full"
                >
                  ✕
                </button>
              ) : (
                <button
                  onClick={sendMessage}
                  className="w-10 h-10 text-blue-600 hover:bg-blue-100 flex items-center justify-center rounded-full"
                >
                  <ArrowUpCircle className="w-7 h-7" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* hidden file inputs */}
      <input
        id="fileInput"
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          const files = e.target.files;
          if (files) setAttachedFiles((prev) => [...prev, ...Array.from(files)]);
        }}
      />

      <input
        id="imageInput"
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => {
          const files = e.target.files;
          if (files) setAttachedFiles((prev) => [...prev, ...Array.from(files)]);
        }}
      />
    </div>
  );
}
