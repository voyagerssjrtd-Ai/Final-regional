// src/components/LoginPage.jsx
import React, { useState } from "react";
import { User, Lock, Eye, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";   // ✅ add this

const API_BASE_URL = "http://127.0.0.1:8000/api"; // FastAPI backend

export default function LoginPage() {
  const [mode, setMode] = useState("login"); // "login" | "register"

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [passwordVisible, setPasswordVisible] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const isLogin = mode === "login";

  const navigate = useNavigate();              // ✅ add this

  const resetMessages = () => {
    setError("");
    setMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    resetMessages();

    if (!email || !password || (!isLogin && !fullName)) {
      setError("Please fill in all required fields.");
      return;
    }

    setSubmitting(true);

    try {
      const endpoint = isLogin ? "/auth/login" : "/auth/register";

      const body = isLogin
        ? { email, password }
        : { email, password, full_name: fullName };

      const res = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      setSubmitting(false);

      if (!res.ok) {
        setError(data.detail || "Something went wrong.");
        return;
      }

      // For both login & register, we get id + email + full_name (register returns via response_model)
      if (data.id) {
        // store user info for future LLM / multi-agent use
        localStorage.setItem("user_id", data.id);
        localStorage.setItem("user_email", data.email);
        localStorage.setItem("user_name", data.full_name || fullName || "");
      }

      if (isLogin) {
        // ✅ directly go to Chat UI after successful login
        navigate("/chat", { replace: true });
      } else {
        // registration flow: either auto-login or ask user to log in
        setMessage(
          `Account created for ${data.full_name || fullName}. You can now log in.`
        );
        setMode("login");
      }
    } catch (err) {
      console.error(err);
      setSubmitting(false);
      setError("Cannot reach server. Is backend running on :8000?");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Brand */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center mb-3 shadow-md">
            <span className="text-white font-bold text-xl">V</span>
          </div>
          <h1 className="text-xl font-semibold text-slate-900 text-center">
            Voyagers Multi-Agent Hub
          </h1>
          <p className="text-xs text-slate-500 mt-1 text-center">
            {isLogin
              ? "Log in to continue your experiments."
              : "Create an account to save your multi-agent workspace."}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 px-6 py-7">
          {/* Toggle Login / Register */}
          <div className="flex justify-center mb-5">
            <div className="inline-flex rounded-full bg-slate-100 p-1 text-xs">
              <button
                type="button"
                onClick={() => {
                  setMode("login");
                  resetMessages();
                }}
                className={`px-4 py-1 rounded-full transition ${
                  isLogin
                    ? "bg-slate-900 text-white shadow"
                    : "text-slate-600 hover:bg-slate-200"
                }`}
              >
                Login
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode("register");
                  resetMessages();
                }}
                className={`px-4 py-1 rounded-full transition ${
                  !isLogin
                    ? "bg-slate-900 text-white shadow"
                    : "text-slate-600 hover:bg-slate-200"
                }`}
              >
                Register
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Full name (only for register) */}
            {!isLogin && (
              <div>
                <label className="block text-xs text-slate-600 mb-1">
                  Full name
                </label>
                <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200 focus-within:ring-2 focus-within:ring-slate-200">
                  <User size={16} className="text-slate-400" />
                  <input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    type="text"
                    placeholder="Swetha Voyagers"
                    className="bg-transparent outline-none w-full text-slate-900 placeholder:text-slate-400 text-sm"
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-xs text-slate-600 mb-1">
                Email
              </label>
              <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200 focus-within:ring-2 focus-within:ring-slate-200">
                <User size={16} className="text-slate-400" />
                <input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  placeholder="you@voyagers.app"
                  className="bg-transparent outline-none w-full text-slate-900 placeholder:text-slate-400 text-sm"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs text-slate-600 mb-1">
                Password
              </label>
              <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200 focus-within:ring-2 focus-within:ring-slate-200 relative">
                <Lock size={16} className="text-slate-400" />
                <input
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  type={passwordVisible ? "text" : "password"}
                  placeholder="••••••••"
                  className="bg-transparent outline-none w-full text-slate-900 placeholder:text-slate-400 text-sm pr-8"
                />
                <button
                  type="button"
                  onClick={() => setPasswordVisible((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500"
                >
                  {passwordVisible ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>

            {/* Error / message */}
            {error && (
              <div className="text-rose-500 text-xs mt-1">{error}</div>
            )}
            {message && (
              <div className="text-emerald-600 text-xs mt-1">{message}</div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full mt-1 py-2.5 rounded-full text-white text-sm font-semibold shadow-md flex items-center justify-center gap-2 transition-colors bg-slate-900 hover:bg-black disabled:opacity-70"
            >
              {submitting ? (
                <span
                  style={{
                    width: 18,
                    height: 18,
                    border: "2px solid rgba(255,255,255,0.45)",
                    borderTop: "2px solid rgba(255,255,255,1)",
                    borderRadius: 999,
                  }}
                  className="animate-spin"
                />
              ) : (
                <span>{isLogin ? "Log in" : "Create account"}</span>
              )}
            </button>
          </form>

          <p className="mt-5 text-[11px] text-slate-400 text-center leading-snug">
            After login, your unique <code>user_id</code> is stored locally.
            Use that ID when calling any multi-agent / LLM backend so it can
            look up your profile and history.
          </p>
        </div>
      </div>
    </div>
  );
}
