// Frontend/src/types/chat.ts

// Basic chat message shape used across frontend
export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt?: string;
}

// Unified ChatMessage type (same as Message)
export type ChatMessage = Message;

// Backend adapter interface
export interface ChatBackend {
  /**
   * Non-streaming call
   * Example backend.sendMessage("hello", { history: [...] })
   */
  sendMessage: (
    text: string,
    opts?: {
      history?: { role: "user" | "assistant"; content: string }[];
    }
  ) => Promise<ChatMessage>;

  /**
   * Optional streaming API
   */
  streamMessage?: (
    payloadText: string,
    onChunk: (chunk: string) => void,
    onComplete: (finalMsg: ChatMessage | null) => void,
    signal?: AbortSignal
  ) => Promise<ChatMessage | null>;
}
