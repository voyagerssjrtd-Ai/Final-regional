// Frontend/src/adapters/BackendAdapter.ts
export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt?: string;
};

const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8000";

// async function sendMessageToBackend(message: string) {
//   const response = await fetch("http://127.0.0.1:8000/api/llm", {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//     },
//     body: JSON.stringify({
//       user_id: 123,        // optional, depends on your backend
//       message: message,    // the text you want to send
//       history: []          // optional, if your backend expects chat history
//     }),
//   });

//   if (!response.ok) {
//     throw new Error(`HTTP error! Status: ${response.status}`);
//   }

//   const data = await response.json();
//   console.log("Backend replied:", data);
//   return data;
// }


async function requestJSON(path: string, body: any) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    // include credentials or auth header here if you add auth
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HTTP ${res.status}: ${text}`);
  }
  return res.json();
}


console.log("API BASE:", import.meta.env.VITE_API_BASE);
export const BackendAdapter = {
  /**
   * sendMessage - non-streaming call that returns a ChatMessage
   */
  async sendMessage(
    text: string,
    opts?: { history?: { role: string; content: string }[] }
  ): Promise<ChatMessage> {
    const user_id_raw = localStorage.getItem("user_id");
    const user_id = user_id_raw ? Number(user_id_raw) : null;

    const payload = {
      user_id,
      message: text,
      history: opts?.history ?? [],
    };

    const data = await requestJSON("/chat", payload);
    // backend returns { role, content }
    return {
      id: Date.now().toString(),
      role: (data.role as "assistant") || "assistant",
      content: data.content ?? "",
      createdAt: new Date().toISOString(),
    };
  },

  /**
   * streamMessage - streaming shim that keeps ChatUI streaming-compatible.
   * If backend is non-streaming we call sendMessage and emit a single chunk + onComplete.
   */
  // async streamMessage(
  //   payloadText: string,
  //   onChunk: (chunk: string) => void,
  //   onComplete: (finalMsg: ChatMessage | null) => void,
  //   signal?: AbortSignal
  // ) {
  //   try {
  //     if (signal?.aborted) throw new DOMException("Aborted", "AbortError");

  //     // Build lightweight history if you want; ChatUI can pass it inside payloadText
  //     const user_id_raw = localStorage.getItem("user_id");
  //     const user_id = user_id_raw ? Number(user_id_raw) : null;

  //     const payload = { user_id, message: payloadText, history: [] };

  //     // Non-streaming HTTP response from backend
  //     const res = await fetch(`${API_BASE}/chat`, {
  //       method: "POST",
  //       headers: { "Content-Type": "application/json" },
  //       body: JSON.stringify(payload),
  //       signal,
  //     });

  //     if (!res.ok) {
  //       const text = await res.text();
  //       throw new Error(`HTTP ${res.status}: ${text}`);
  //     }

  //     const data = await res.json(); // { role, content }

  //     // Send content as a single chunk so UI shows response immediately
  //     const content = data.content ?? "";
  //     onChunk(content);

  //     const msg: ChatMessage = {
  //       id: Date.now().toString(),
  //       role: data.role || "assistant",
  //       content,
  //       createdAt: new Date().toISOString(),
  //     };

  //     onComplete(msg);
  //     return msg;
  //   } catch (err: any) {
  //     if (err?.name === "AbortError") {
  //       // propagate abort so calling code can detect it
  //       throw err;
  //     }
  //     console.error("BackendAdapter.streamMessage error:", err);
  //     onComplete(null);
  //     throw err;
  //   }
  // },
};

export default BackendAdapter;
