// src/adapters/chatservice.ts

import { ChatBackend } from "../types/chat";

export async function handleUserInput(
  backend: ChatBackend,
  text: string,
  files: File[]
) {
  return backend.sendMessage(text, files);
}
